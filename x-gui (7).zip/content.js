window.addEventListener("message", (event) => {
    if (event.source !== window) return;

    if (event.data.type === "FROM_PAGE_CRASH_GAME") {
        chrome.runtime.sendMessage({ type: "CRASH_GAME" }, (response) => {
            console.log(response);
        });
    }
});